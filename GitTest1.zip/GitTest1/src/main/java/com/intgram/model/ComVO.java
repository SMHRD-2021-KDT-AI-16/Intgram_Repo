package com.intgram.model;

public class ComVO {
	private String com_id;
	private String com_name;
	private String com_addr;
	private String com_type;
	private String com_employees;
	public String getCom_id() {
		return com_id;
	}
	public void setCom_id(String com_id) {
		this.com_id = com_id;
	}
	public String getCom_name() {
		return com_name;
	}
	public void setCom_name(String com_name) {
		this.com_name = com_name;
	}
	public String getCom_addr() {
		return com_addr;
	}
	public void setCom_addr(String com_addr) {
		this.com_addr = com_addr;
	}
	public String getCom_type() {
		return com_type;
	}
	public void setCom_type(String com_type) {
		this.com_type = com_type;
	}
	public String getCom_employees() {
		return com_employees;
	}
	public void setCom_employees(String com_employees) {
		this.com_employees = com_employees;
	}
	
	
}
