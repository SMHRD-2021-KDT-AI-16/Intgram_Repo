// import 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.bundle.min.js';
// import 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js';
// import 'https://cdn.jsdelivr.net/npm/chart.js';

//import '../json/gas.json'
// 차트를 그럴 영역을 dom요소로 가져온다.
let data_nonIron = [];
//let page = document.querySelector('input')

//
let all = [];
let totalEmissions = [];
let netEmissions = [];

	
	  
	